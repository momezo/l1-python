msg = "hello world"
print(msg.capitalize())
